// Função para verificar se o e-mail e a senha estão corretos
document.getElementById('login-form').addEventListener('submit', function(event) {
    event.preventDefault(); // Previne o envio padrão do formulário
  
    // Pega os valores do formulário
    const email = document.getElementById('email').value;
    const senha = document.getElementById('senha').value;
  
    // (email e senha corretos para exemplo)
    const usuariosCadastrados = [
      { email: 'henricosanches242@gmail.com', senha: '12345' },
    ];
  
    // Função de validação
    const usuario = usuariosCadastrados.find(user => user.email === email && user.senha === senha);
  
    // Se o usuário for encontrado e os dados forem corretos
    if (usuario) {
      // Redireciona para a página de dados
      window.location.href = 'dados.html';
    } else {
      alert('E-mail ou senha incorretos!');
    }
  });
  